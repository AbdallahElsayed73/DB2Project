public class SQLTerm {
}
