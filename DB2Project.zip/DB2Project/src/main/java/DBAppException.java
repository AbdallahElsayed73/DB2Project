public class DBAppException extends Exception{

    public DBAppException(String s)
    {
        super(s);
    }
}
